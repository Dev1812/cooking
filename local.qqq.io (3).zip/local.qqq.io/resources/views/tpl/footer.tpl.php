







<div style="text-align: center;;">
	<div style="width:70%;margin:0 auto;border-top: 1px solid #CCC;padding:14px 0">
	<div>Scamle &copy; 2023</div></div>
</div>

</div>
</div>
</body>
</html>