<?php
require SITE_ROOT.'/resources/views/tpl/sidebar.tpl.php';
require SITE_ROOT.'/resources/views/tpl/head.tpl.php';
require SITE_ROOT.'/resources/views/tpl/common.tpl.php';
?>




















<div class="reg_content">




<style type="text/css">
.reg_content{margin:74px 0;}
</style>




















<style type="text/css">
	
.form_big_input_section__text_field{height:41px;padding:0 14px;width: 100%;border: 1px solid #CCC;border-radius:5px}
.form_big_input_section__text_field:focus{outline: none;border:1px solid blue;}
.form_block{width:290px;margin:0 auto;}
.form_title{font-size:1.7em;text-align: center;}
.form_big_input_section__title{position: relative;top:11px}
.form_big_input_section__title_label{margin:0 12px;background-color: #FFF}
.button{width: 100%;height:31px;line-height:31px;background-color: #607d8b;font-weight: bold;color: #FFF;border:0;border-radius:5px;cursor: pointer;}
</style>
<div class="form_block">

<div class="form_title">Регистрация</div>

<div class="form_body">

<FORM action="" method="POST">

	<?php

if(!empty($result)){
	var_dump($result);
} 



	?>
	@csrf
<div class="form_section">
	<div class="form_big_input_section__title"><span class="form_big_input_section__title_label">Имя:</span></div>

	<div class="form_big_input_section__body">
		<div class="form_big_input_section__wrap"><input type="text" name="reg_first_name" placeholder="Ваше имя" class="form_big_input_section__text_field"></div>
	</div>
</div>


<div class="form_section">
	<div class="form_big_input_section__title"><span class="form_big_input_section__title_label">Фамилия:</span></div>

	<div class="form_big_input_section__body">
		<div class="form_big_input_section__wrap"><input type="text" name="reg_last_name" placeholder="Ваша фамилия" class="form_big_input_section__text_field"></div>
	</div>
</div>


<div class="form_section">
	<div class="form_big_input_section__title"><span class="form_big_input_section__title_label">Логин:</span></div>

	<div class="form_big_input_section__body">
		<div class="form_big_input_section__wrap"><input type="text" name="reg_login" placeholder="Ваш логин" class="form_big_input_section__text_field"></div>
	</div>
</div>


<div class="form_section">
	<div class="form_big_input_section__title"><span class="form_big_input_section__title_label">Email:</span></div>

	<div class="form_big_input_section__body">
		<div class="form_big_input_section__wrap"><input type="text" name="reg_email" placeholder="Ваш email" class="form_big_input_section__text_field"></div>
	</div>
</div>

<div class="form_section">
	<div class="form_big_input_section__title"><span class="form_big_input_section__title_label">Пароль:</span></div>

	<div class="form_big_input_section__body">
		<div class="form_big_input_section__wrap"><input type="text" name="reg_password" placeholder="Ваш пароль" class="form_big_input_section__text_field"></div>
	</div>
</div>


<div class="form_section" style="margin-top: 9px">
	<div class="form_big_input_section__body">
		<div class="form_big_input_section__wrap"><input type="submit" name="reg_submit" placeholder="Ваше Имя" class="button" value="Зарегестрироваться"></div>
	</div>
</div>
</FORM>
</div>

</div>


















</div>







